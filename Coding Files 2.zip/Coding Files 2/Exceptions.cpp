// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/*
Name: Sabrina Ozburn
Date: 3/23/2026
*/


#include <iostream>

// CustomException class that extends from std::exception
struct CustomException : public std::exception 
{
public:
    const char* what() const noexcept override 
    { 
        return "A custom exception has occured.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw any standard exception
    throw std::exception("Error.");

    return true;
}
void do_custom_application_logic()
{
    // Wrap the call to do_even_more_custom_application_logic()
    // with an exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception) 
    {
        // Display message and exception.what(), then continue processing
        std::cout << "A standard exception has been caught. " << exception.what() << '\n';
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // Throw a custom exception derived from std::exception
    throw CustomException();

}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors
    if (den == 0)
    {
        throw std::overflow_error("Divide by zero error."); // Throw an error for Divide by zero
    }
    return (num / den);
}

void do_division() noexcept
{
    //  Create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Exception message: " << exception.what() << std::endl;
    }
    
}

int main()
{
    // Create exception handlers that catch (in this order):
    // your custom exception
    // std::exception
    // uncaught exception 
    // that wraps the whole main function, and displays a message to the console.

    try
    {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    catch (CustomException& exception) // Catch the custom exception
    {
        std::cout << "Error code: " << exception.what() << std::endl;
    }
    catch (std::exception& exception) // Catch any standard exception
    {
        std::cout << "Error code: " << exception.what() << std::endl;
    }
    catch (...) // Catch all other uncaught exceptions
    {
        std::cout << "An exception has been caught.\n" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu